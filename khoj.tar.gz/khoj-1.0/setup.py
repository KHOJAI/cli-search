from setuptools import setup

setup(
    name='khoj',
    version='1.0',
    py_modules=['khoj'],
    install_requires=[
        'requests',
        'colorama'
    ],
    entry_points={
        'console_scripts': [
            'khoj=khoj:main'
        ]
    }
)
